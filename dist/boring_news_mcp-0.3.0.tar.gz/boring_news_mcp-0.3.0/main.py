def main():
    print("Hello from mcp!")


if __name__ == "__main__":
    main()
